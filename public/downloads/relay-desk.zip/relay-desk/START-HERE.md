# Run this Relay Desk download

Extract the archive, install Node.js 24 or newer, and open a terminal inside
the extracted `relay-desk` folder (the folder containing `package.json`).

```sh
npm start
```

Open http://127.0.0.1:3210. No installation of npm packages, API credential,
or payment is required for the default extractive mode. Stop with Ctrl+C.
On Windows, use `npm.cmd` if PowerShell blocks the npm launcher.

Run the checks in that same folder:

```sh
npm test
npm run evaluate
```

The included README explains the workflow, architecture, optional model setup,
and limitations. Run its commands from the extracted folder containing package.json.

This is a local, single-user demonstration with a mock CRM and fictional data.
The download contains no local database, credentials, or configured live model.
The app creates its own `data` folder on first run. Do not host it publicly
without adding the access and data-handling controls described in the README.
